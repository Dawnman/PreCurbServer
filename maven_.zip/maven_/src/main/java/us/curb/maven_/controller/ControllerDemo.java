package us.curb.maven_.controller;

import java.util.List;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import us.curb.maven_.dao.CourseDao;
import us.curb.maven_.dao.UserDao;
import us.curb.maven_.pojo.Course;
import us.curb.maven_.serviceimpl.UserServiceImpl;

@RequestMapping("")
@RestController
public class ControllerDemo {

	@Autowired
	CourseDao courseDao;
	@Autowired
	UserServiceImpl userServiceImpl;
	@Autowired
	UserDao userDao;
	
	@RequestMapping(value="/showJson",method = RequestMethod.GET)
	public @ResponseBody List<Course> show(){
		return courseDao.listCourse();
	}
	
	//用户用学者网帐号密码获取信息
	@RequestMapping(value="/curbScholat",method=RequestMethod.POST)
	public @ResponseBody String curbLogin(HttpServletRequest request, HttpServletResponse response, int userKey,
			String userName, String password){
		int userid = 0;
		userid = userDao.getId(userName);
		if(userid == 0){
			/*
			 * addUserFromClient要改成仅仅是添加用户的功能
			 */
			userServiceImpl.addUserFromClient(userKey, userName, password);//retun CourseList
			/*
			 * 抓取课程和作业信息并将未提交的作业id添加到unfinish表中
			 */
			
			/*
			 * 根据unfinish表中的courseid和homeworkid将作业信息返回给客户端
			 */
		}else{
			/*
			 *检查未提交作业的表的信息
			 */
			
			/*
			 * 根据unfinish表中的courseid和homeworkid将作业信息返回给客户端
			 */
		}
		
		return null;
	}
	
	
//	@RequestMapping(value="/crawScholar",method = RequestMethod.GET)
//	public @ResponseBody CourseAndHomework(){
//		
//	}
	
	
	
}
