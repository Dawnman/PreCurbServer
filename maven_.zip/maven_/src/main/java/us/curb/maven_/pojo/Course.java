package us.curb.maven_.pojo;

public class Course {

	 private int courseId;

	    private String title;

	    private String teacher;

	    private String url;

		public int getCourseId() {
			return courseId;
		}

		public void setCourseId(int courseId) {
			this.courseId = courseId;
		}

		public String getTitle() {
			return title;
		}

		public void setTitle(String title) {
			this.title = title;
		}

		public String getTeacher() {
			return teacher;
		}

		public void setTeacher(String teacher) {
			this.teacher = teacher;
		}

		public String getUrl() {
			return url;
		}

		public void setUrl(String url) {
			this.url = url;
		}

		@Override
		public String toString() {
			return "Course [courseId=" + courseId + ", title=" + title + ", teacher=" + teacher + ", url=" + url + "]";
		}

	    
	
}
