package us.curb.maven_.testdemo;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import us.codecraft.webmagic.Request;
import us.codecraft.webmagic.Spider;
import us.codecraft.webmagic.model.HttpRequestBody;
import us.codecraft.webmagic.pipeline.ConsolePipeline;
import us.codecraft.webmagic.utils.HttpConstant;
import us.curb.maven_.crawscholar.CrawScholar;
import us.curb.maven_.dao.CourseDao;


public class TestDemo {

	@Autowired
	CourseDao courseDao;

	
	@Test
	public void craw(){
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("classpath:/spring/applicationContext*.xml");
		CrawScholar crawScholar = applicationContext.getBean(CrawScholar.class);
		crawScholar.init(1,"lifumin","lg5684902");
		Request request = new Request("http://www.scholat.com/Auth.html");
		request.setMethod(HttpConstant.Method.POST);
		//request.setExtras(crawScholar.nameValuePair);
		request.addCookie("JSESSIONID",crawScholar.getLogin().cookie);
		request.setRequestBody(HttpRequestBody.form(crawScholar.getFormMap(), "utf-8"));
		Spider spider = Spider.create(crawScholar);
		spider.addRequest(request);
		
		spider.addPipeline(new ConsolePipeline()).addPipeline(crawScholar.getCrawScholarPipeline());
		//spider.addUrl("http://www.scholat.com/getCourseList.html?type=3");
		spider.thread(1).run();
		if(crawScholar.getErrCode()==0){
			System.out.println("登陆信息错误！！！");
		}
		else{
			System.out.println("登陆信息正确！！！");
		}
	}
	
	
	public void test(){
		//List<String> strlist = new ArrayList<String>();
		//System.out.println(strlist.size());
		
		String str = "未提交";
		if(str == "未提交"){
			System.out.println(true);
		}
		
	}
	
	
}
